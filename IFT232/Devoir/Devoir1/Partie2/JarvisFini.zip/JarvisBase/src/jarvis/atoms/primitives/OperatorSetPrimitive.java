package jarvis.atoms.primitives;

import java.util.ArrayList;

import jarvis.atoms.AbstractAtom;
import jarvis.atoms.ListAtom;
import jarvis.atoms.ObjectAtom;
import jarvis.atoms.StringAtom;
import jarvis.interpreter.JarvisInterpreter;

public class OperatorSetPrimitive extends PrimitiveOperationAtom{

	/*
	 * Triche pour pouvoir avoir des arguments variables.
	 * Le nombre d'arguments n�cessaire est d�termin� par la taille
	 * de la liste des attributs de la classe qui cr�e l'instance.
	 */
	protected void init() {
		argCount = -1;
	}
	
	
	//H�RITAGE	
	/*
	 * Operator set
	 * Rien de bien myst�rieux: Lorsqu'on fabrique un objet
	 * il suffit de prendre les arguments re�us et de les copier
	 * un � un dans l'objet qu'on fabrique.
	 * Devient plus complexe si on h�rite les membres d'une autre classe.
	 * 
	 */
	@Override
	protected AbstractAtom execute(JarvisInterpreter ji,ObjectAtom self) {	
		
		
		//Seule une classe peut faire set. Ramasser de la classe combien d'attributs �a prend.
		
		ArrayList<AbstractAtom> data = self.getVals();
		data.set(((ListAtom)self.getJarvisClass().getVals().get(0)).find(ji.getArg()), ji.getArg());	
		
		return self;					
	}

	@Override
	public String makeKey() {
		
		return "OperatorSetPrimitive";
	}
}
