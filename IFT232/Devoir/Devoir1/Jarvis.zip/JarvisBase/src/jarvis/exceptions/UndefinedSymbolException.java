package jarvis.exceptions;

public class UndefinedSymbolException extends RuntimeException {

	
	
	
	public UndefinedSymbolException(String m)
	{
		super(m);
	}
	
	private static final long serialVersionUID = -1066471157710161721L;

}
