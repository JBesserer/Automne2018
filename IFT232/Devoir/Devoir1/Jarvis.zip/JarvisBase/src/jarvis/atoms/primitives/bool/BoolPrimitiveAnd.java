package jarvis.atoms.primitives.bool;

import java.util.ArrayList;

import jarvis.atoms.AbstractAtom;
import jarvis.atoms.BoolAtom;
import jarvis.atoms.ObjectAtom;
import jarvis.interpreter.JarvisInterpreter;

public class BoolPrimitiveAnd extends BoolPrimitiveOperation{
	/* 
	 * Le nombre d'argument pour toutes les op�rations d�riv�es de celle-ci sera
	 * de 2 (self + 1 autre). Il devrait donc rester un argument dans la file � cette �tape-ci
	 * Ne supporte que des op�rations binaires (2 arguments).
	 */
	protected void init() {
		argCount = 1;
	}
	
	@Override
	public String makeKey() {
		
		return "BoolPrimitiveAnd";
	}
	@Override
	protected AbstractAtom calculateResult(JarvisInterpreter ji, BoolAtom val1, BoolAtom val2) {
		
		// C'est ici que l'op�ration r�elle a lieu
		boolean total = val1.getValue() && val2.getValue();	
		
		// Ici, construit un objet int manuellement
		// � noter, on retourne un objet de type bool, pas un atome de type bool.
		ArrayList<AbstractAtom> data = new ArrayList<AbstractAtom>();
		data.add(new BoolAtom(total));
		
		return new ObjectAtom(((ObjectAtom)ji.getEnvironment().get("bool")),data,ji);
	}

}
