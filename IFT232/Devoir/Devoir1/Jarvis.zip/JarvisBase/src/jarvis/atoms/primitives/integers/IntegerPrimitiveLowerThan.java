package jarvis.atoms.primitives.integers;

import java.util.ArrayList;

import jarvis.atoms.AbstractAtom;
import jarvis.atoms.BoolAtom;
import jarvis.atoms.IntAtom;
import jarvis.atoms.ObjectAtom;
import jarvis.interpreter.JarvisInterpreter;

public class IntegerPrimitiveLowerThan extends IntegerPrimitiveOperation {

	@Override
	public String makeKey() {
		
		return "IntegerPrimitiveLowerThan";
	}
	@Override
	protected AbstractAtom calculateResult(JarvisInterpreter ji, IntAtom val1, IntAtom val2) {
		
		// C'est ici que l'op�ration r�elle a lieu
		boolean value = val1.getValue() < val2.getValue();	
		
		// Ici, construit un objet bool manuellement
		// � noter, on retourne un objet de type bool, pas un atome de type bool.
		ArrayList<AbstractAtom> data = new ArrayList<AbstractAtom>();
		data.add(new BoolAtom(value));
		
		return new ObjectAtom(((ObjectAtom)ji.getEnvironment().get("bool")),data,ji);
	}
}
