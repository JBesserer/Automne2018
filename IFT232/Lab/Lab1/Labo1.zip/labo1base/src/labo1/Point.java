package labo1;

import java.awt.Graphics2D;
import java.util.Scanner;

public class Point extends Dessin{
	
	private int x;
	private int y;
	
	public Point(){
		x=0;
		y=0;
	}
	
	public Point(int x, int y){
		this.x=x;
		this.y=y;
	}
	
	/*
	 * Fonction qui dessine le point sur la surface 2D.
	 */
	//@Override
	public void dessiner(Graphics2D graph){
		graph.drawString("X", x, y);
	}
	
	/*
	 * Fonction qui obtient les coordonn�es du point 
	 * � partir d'un flot d'entiers
	 */
	//@Override
	public void lire(Scanner reader) {		
		x=reader.nextInt();
		y=reader.nextInt();		
		
	}
	
	public int getX() {
		return this.x;
	}
	
	public int getY() {
		return this.y;
	}
	
	//@Override
	public String toString() { 
	    return "(" + this.x+","+this.y+")" ;
	} 
	
	@Override
	public boolean equals(Object other){
		//Tautological tests
	    if (other == null) return false;
	    if (other == this) return true;
	    if (!(other instanceof Point))return false;
	    
	    //Variable tests
	    Point otherPoint = (Point)other;
	    if(this.x == otherPoint.x  && this.y == otherPoint.y)return true;
	    return false;
	}
}
