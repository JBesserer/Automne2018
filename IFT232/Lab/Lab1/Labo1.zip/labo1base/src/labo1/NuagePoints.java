package labo1;

import java.awt.Graphics2D;
import java.util.ArrayList;
import java.util.NoSuchElementException;
import java.util.Scanner;

public class NuagePoints extends Dessin{
	private ArrayList<Point> pointCloud;
	
	public NuagePoints(){
		pointCloud = new ArrayList<Point>();
	}
	
	
	/*
	 * Fonction qui dessine le point sur la surface 2D.
	 */
	//@Override
	public void dessiner(Graphics2D graph){
		for(Point point: pointCloud) {
			point.dessiner(graph);
		}
	}
	
	/*
	 * Fonction qui obtient les coordonn�es du point 
	 * � partir d'un flot d'entiers
	 */
	//@Override
	public void lire(Scanner reader) {		
		int size=reader.nextInt();	
		
		if(size > 0) {
			for(int i = 0; i < size; ++i) {
				try {
					Point newPoint = new Point(reader.nextInt(),reader.nextInt());
					if(!pointCloud.contains(newPoint)) {
						pointCloud.add(newPoint);
					}
				}
				catch(NoSuchElementException e) {
					System.out.println("Number of points is too low for the size required. Stopping at "+i+" points.");
					break;
				}
			}
		}
	}
	
	@Override
	public String toString() {
		String cloudString = "";
		for(Point point: pointCloud) {
			cloudString += point.toString() +"\n";
		}
		
		return cloudString;
	} 
	
	public ArrayList<Point> getPointCloud(){
		return pointCloud;
	}
}
