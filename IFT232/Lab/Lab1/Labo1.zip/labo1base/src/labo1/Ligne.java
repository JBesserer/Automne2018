package labo1;

import java.awt.Graphics2D;
import java.util.Scanner;

public class Ligne extends Dessin{
	private Point point1;
	private Point point2;
	
	public Ligne(){
		point1 = new Point();
		point2 = new Point();
	}
	
	public Ligne(Point point1, Point point2){
		this.point1 = point1;
		this.point2 = point2;
	}
	
	/*
	 * Fonction qui dessine le point sur la surface 2D.
	 */
	@Override
	public void dessiner(Graphics2D graph){
		graph.drawLine(point1.getX(), point1.getY(), point2.getX(), point2.getY());
	}
	
	/*
	 * Fonction qui obtient les coordonn�es du point 
	 * � partir d'un flot d'entiers
	 */
	@Override
	public void lire(Scanner reader) {	
		point1.lire(reader);
		point2.lire(reader);
	}
	
	@Override
	public String toString() { 
	    return "(" + this.point1.getX()+","+this.point1.getY()+") -> ("+ this.point2.getX()+","+this.point2.getY()+")" ;
	} 
}
