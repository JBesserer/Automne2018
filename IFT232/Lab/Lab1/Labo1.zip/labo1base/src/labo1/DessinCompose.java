package labo1;

import java.awt.Graphics2D;
import java.util.ArrayList;
import java.util.Scanner;

public class DessinCompose extends Dessin{
	private ArrayList<Dessin> dessins;
	
	public DessinCompose() {
		dessins = new ArrayList<Dessin>();
	}
	
	public void dessiner(Graphics2D graph) {
		for(Dessin dessin: dessins) {
			dessin.dessiner(graph);
		}
	}
	
	//@Override
	public void lire(Scanner reader) {
		while(reader.hasNext()){
			int delimiter = reader.nextInt();
			if(delimiter < 0) {
				dessins.add(Dessin.typeDessin(delimiter));
				dessins.get(dessins.size()-1).lire(reader);
			}
		}
	}
}
