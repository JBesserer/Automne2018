package labo1;

import java.awt.Graphics2D;
import java.util.Scanner;

abstract public class Dessin {

	/*
	 * Fonction qui dessine le point sur la surface 2D.
	 */
	
	public abstract void dessiner(Graphics2D graph);
	
	/*
	 * Fonction qui obtient les coordonn�es du point 
	 * � partir d'un flot d'entiers
	 */
	public abstract void lire(Scanner reader);

	/*
	 * Fonction de factory pour les differents types de dessins
	 */
	public static Dessin typeDessin(int type) {
		if(type == -1) {
			Point dessin = new Point();
			return dessin;
		}else if(type == -2) {
			Ligne dessin = new Ligne();
			return dessin;
		}else if(type == -3) {
			NuagePoints dessin = new NuagePoints();
			return dessin;
		}else {
			Polygone dessin = new Polygone();
			return dessin;
		}
		
	}
}
