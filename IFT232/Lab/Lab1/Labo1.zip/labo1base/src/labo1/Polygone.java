package labo1;

import java.awt.Graphics2D;
import java.util.ArrayList;
import java.util.Scanner;

public class Polygone extends Dessin{
	
	private NuagePoints pointCloud;
	
	public Polygone() {
		pointCloud = new NuagePoints();
	}
	
	/*
	 * Fonction qui dessine le point sur la surface 2D.
	 */
	@Override
	public void dessiner(Graphics2D graph){
		pointCloud.dessiner(graph);
		
		ArrayList<Point> points = pointCloud.getPointCloud();
		
		for(int i = 0;i< points.size();++i) {
			if(i !=points.size()-1) {
				Ligne newline = new Ligne(points.get(i),points.get(i+1));
				newline.dessiner(graph);
			}else {
				Ligne newline = new Ligne(points.get(i),points.get(0));
				newline.dessiner(graph);
			}
		}
	}
	
	/*
	 * Fonction qui obtient les coordonn�es du point 
	 * � partir d'un flot d'entiers
	 */
	@Override
	public void lire(Scanner reader) {		
		pointCloud.lire(reader);
	}
}
